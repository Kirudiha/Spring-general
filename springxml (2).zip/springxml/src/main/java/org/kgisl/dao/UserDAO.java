package org.kgisl.dao;

import java.util.List;

import org.kgisl.model.User;
 
 
public interface UserDAO {
    public List<User> listUsers();
}
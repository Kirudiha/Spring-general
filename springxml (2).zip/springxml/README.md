```
INSERT INTO `users`(`USER_ID`, `USERNAME`, `PASSWORD`, `EMAIL`) VALUES (1,'username1','password1','username1@springxml.com');
INSERT INTO `users`(`USER_ID`, `USERNAME`, `PASSWORD`, `EMAIL`) VALUES (2,'username2','password2','username2@springxml.com');
INSERT INTO `users`(`USER_ID`, `USERNAME`, `PASSWORD`, `EMAIL`) VALUES (3,'username3','password3','username3@springxml.com');
INSERT INTO `users`(`USER_ID`, `USERNAME`, `PASSWORD`, `EMAIL`) VALUES (4,'username4','password4','username4@springxml.com');
INSERT INTO `users`(`USER_ID`, `USERNAME`, `PASSWORD`, `EMAIL`) VALUES (5,'username5','password5','username5@springxml.com');
```

[org.springframework.orm.hibernate4](https://docs.spring.io/spring/docs/3.1.x/javadoc-api/org/springframework/orm/hibernate4/package-frame.html)